<?php

// ----------------------------------------------------------------------------------
// Class: Object
// ----------------------------------------------------------------------------------

/**
 * An abstract object.
 * Root object with some general methods, that should be overloaded. 
 * 
 *
 * @version  $Id: Object.php,v 1.1 2007/09/18 08:42:54 halo12 Exp $
 * @author Chris Bizer <chris@bizer.de>
 *
 * @abstract
 * @package utility
 *
 **/
 class Object {

  /**
   * Serializes a object into a string
   *
   * @access	public
   * @return	string		
   */    
	function toString() {
    	$objectvars = get_object_vars($this);
		foreach($objectvars as $key => $value) 
			$content .= $key ."='". $value. "'; ";
		return "Instance of " . get_class($this) ."; Properties: ". $content;
	}

 }


?>