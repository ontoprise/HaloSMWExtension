<?php
/**
*   Exception when generating the SQL statement
*
*   @author Christian Weiske <cweiske@cweiske.de>
*
*   @package sparql
*/
class SparqlEngineDb_SqlGeneratorException extends Exception
{
}

?>