<?php
/**
*   A prepared statement that can be execute()d later multiple
*   times with different variable values.
*
*   @package sparql
*/
class SparqlEngine_PreparedStatement
{
    public function execute($arVariables, $resultform)
    {
        //FIXME
    }

}
?>