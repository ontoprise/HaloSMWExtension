<?php
// ----------------------------------------------------------------------------------
// Syntax SparqlRes
// ----------------------------------------------------------------------------------
//
// Description               : Syntax Sparql Result package
//
// Author: Tobias Gau�	<tobias.gauss@web.de>
//
// ----------------------------------------------------------------------------------


// Include Syntax classes
require_once( RDFAPI_INCLUDE_DIR . 'syntax/SparqlResultParser.php' );
?>