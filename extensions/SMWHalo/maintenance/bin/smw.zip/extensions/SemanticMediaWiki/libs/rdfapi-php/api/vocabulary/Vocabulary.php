<?php
/**
*   Vocabulary
*
*   @version $Id: Vocabulary.php,v 1.1 2007/09/18 08:42:56 halo12 Exp $
*   @author Tobias Gauß <tobias.gauss@web.de>
*   @package vocabulary
*
*/

// Include vocabularies
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/RDF.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/RDFS.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/OWL.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/DC.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/VCARD.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/FOAF.php';
require_once RDFAPI_INCLUDE_DIR . 'vocabulary/RSS.php';
?>