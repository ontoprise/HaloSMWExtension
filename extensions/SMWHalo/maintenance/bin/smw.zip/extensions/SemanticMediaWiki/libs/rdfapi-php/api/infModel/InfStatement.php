<?php
// ----------------------------------------------------------------------------------
// Class: InfStatement
// ----------------------------------------------------------------------------------

/**
 * An RDF statement which was entailed by a inference rule.
 * See Statement Class for further information. 
 *  
 * @author Daniel Westphal <mail at d-westphal dot de>
 * @version  $Id: InfStatement.php,v 1.1 2007/09/18 08:43:01 halo12 Exp $
 * @package infModel
 */
class InfStatement extends Statement  {
	
}
	
?>