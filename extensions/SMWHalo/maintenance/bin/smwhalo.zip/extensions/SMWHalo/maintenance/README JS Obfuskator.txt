You need to install Jasob 2.1
available at: www.jasob.com

and change the launch config to your location of jasob.exe if necessary.

To create a deployable build:

- Run script: SMW_copyScripts.php to copy all JS scripts to a temporary dir. (c:\temp\halo_js_scripts)
- Run Jasob with the given launch config
- Run script: SMW_packScripts.php

